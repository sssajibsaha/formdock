const { createApp } = require('./lib/app');

const port = Number(process.env.PORT) || 3000;
const app = createApp();

app.listen(port, () => {
  console.log(`FormDock listening on port ${port}`);
  if (!process.env.ADMIN_PASSWORD) {
    console.warn('ADMIN_PASSWORD is not set. The dashboard stays locked until you set it.');
  }
});
