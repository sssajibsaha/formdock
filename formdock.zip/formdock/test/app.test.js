const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createApp } = require('../lib/app');

let server, base, cookie, formId;
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'formdock-'));

test.before(async () => {
  server = createApp({ dataDir, adminPassword: 'test-pass', submitsPerMinute: 6 }).listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => {
  server.close();
  fs.rmSync(dataDir, { recursive: true, force: true });
});

const post = (url, body, headers = {}) =>
  fetch(base + url, { method: 'POST', body: new URLSearchParams(body), headers, redirect: 'manual' });

test('dashboard requires login', async () => {
  const res = await fetch(base + '/', { redirect: 'manual' });
  assert.strictEqual(res.status, 302);
  assert.strictEqual(res.headers.get('location'), '/login');
});

test('wrong password is rejected, right password sets a session', async () => {
  assert.strictEqual((await post('/login', { password: 'nope' })).status, 401);
  const res = await post('/login', { password: 'test-pass' });
  assert.strictEqual(res.status, 302);
  cookie = res.headers.get('set-cookie').split(';')[0];
  assert.match(res.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
});

test('a forged session cookie is rejected', async () => {
  const res = await fetch(base + '/', { headers: { cookie: `fd_session=${Date.now() + 1e6}.deadbeef` }, redirect: 'manual' });
  assert.strictEqual(res.status, 302);
});

test('create a form', async () => {
  const res = await post('/forms', { name: 'Contact' }, { cookie });
  assert.strictEqual(res.status, 302);
  formId = res.headers.get('location').split('/').pop();
  assert.match(formId, /^[0-9a-f]{12}$/);
});

test('cross-origin dashboard POST is blocked', async () => {
  const res = await post('/forms', { name: 'Evil' }, { cookie, origin: 'https://evil.example' });
  assert.strictEqual(res.status, 403);
});

test('public submit stores fields, drops _private keys, escapes HTML in dashboard', async () => {
  const res = await post(`/f/${formId}`, { email: 'a@b.co', message: '<script>alert(1)</script>', _next: 'https://evil.example' });
  assert.strictEqual(res.status, 200);
  const html = await (await fetch(`${base}/forms/${formId}`, { headers: { cookie } })).text();
  assert.ok(html.includes('a@b.co'));
  assert.ok(html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
  assert.ok(!html.includes('<script>alert(1)</script>'));
  assert.ok(!html.includes('evil.example'));
});

test('JSON submit returns JSON and CORS header', async () => {
  const res = await fetch(`${base}/f/${formId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Ada' }),
  });
  assert.deepStrictEqual(await res.json(), { ok: true });
  assert.strictEqual(res.headers.get('access-control-allow-origin'), '*');
});

test('honeypot submissions report success but are not stored', async () => {
  const res = await post(`/f/${formId}`, { email: 'bot@spam.io', _gotcha: 'x' });
  assert.strictEqual(res.status, 200);
  const html = await (await fetch(`${base}/forms/${formId}`, { headers: { cookie } })).text();
  assert.ok(!html.includes('bot@spam.io'));
});

test('empty and unknown-form submissions fail', async () => {
  assert.strictEqual((await post(`/f/${formId}`, { _only: 'x' })).status, 400);
  assert.strictEqual((await post('/f/doesnotexist', { a: 'b' })).status, 404);
  assert.strictEqual((await post('/f/__proto__', { a: 'b' })).status, 404);
});

test('settings reject non-http URLs and redirect works when set', async () => {
  let res = await post(`/forms/${formId}/settings`, { name: 'Contact', redirect: 'javascript:alert(1)' }, { cookie });
  assert.match(res.headers.get('location'), /error=1/);
  res = await post(`/forms/${formId}/settings`, { name: 'Contact', redirect: 'https://example.com/thanks' }, { cookie });
  assert.ok(!res.headers.get('location').includes('error'));
  res = await post(`/f/${formId}`, { email: 'c@d.co' });
  assert.strictEqual(res.status, 303);
  assert.strictEqual(res.headers.get('location'), 'https://example.com/thanks');
});

test('CSV export neutralises formula injection', async () => {
  await post(`/f/${formId}`, { email: '=HYPERLINK("http://x")' });
  const res = await fetch(`${base}/forms/${formId}/export.csv`, { headers: { cookie } });
  const csv = await res.text();
  assert.match(res.headers.get('content-type'), /text\/csv/);
  assert.ok(csv.includes(`"'=HYPERLINK(""http://x"")"`));
});

test('submissions are rate limited per IP', async () => {
  // 6/min in this test app; earlier tests already used the allowance.
  const res = await post(`/f/${formId}`, { email: 'late@x.co' });
  assert.strictEqual(res.status, 429);
});

test('export requires login', async () => {
  const res = await fetch(`${base}/forms/${formId}/export.csv`, { redirect: 'manual' });
  assert.strictEqual(res.status, 302);
});
