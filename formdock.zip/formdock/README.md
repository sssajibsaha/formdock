# FormDock

A self-hosted form backend. Point any HTML form at FormDock and read the submissions in your own dashboard. No third-party form service, no per-submission pricing, no database to set up.

Built for static sites, landing pages and client sites that need a contact form and nothing else.

<!-- After listing the repo in Hostinger's open source program, paste the Deploy to Hostinger button it gives you here. -->

## What it does

- One endpoint per form: `POST /f/<form-id>` accepts normal HTML form posts and JSON
- Password-protected dashboard to create forms and read, delete and export submissions (CSV)
- Honeypot spam trap (`_gotcha`) and per-IP rate limiting
- Optional redirect to your own thank-you page
- Optional webhook: every submission is forwarded as JSON (Zapier, Make, n8n, GoHighLevel, Slack)
- One dependency (Express). Data lives in a single JSON file

## Run it

```bash
git clone https://github.com/YOUR_USERNAME/formdock.git
cd formdock
npm install
ADMIN_PASSWORD=choose-a-long-password npm start
```

Open `http://localhost:3000`, log in, create a form, and copy the snippet it shows you.

## Settings

| Variable | Required | Default | What it does |
| --- | --- | --- | --- |
| `ADMIN_PASSWORD` | Yes | none | Dashboard password. The dashboard stays locked until it is set. |
| `PORT` | No | `3000` | Port to listen on. |
| `DATA_DIR` | No | `./data` | Folder for `formdock.json`. Point it somewhere that survives redeploys. |

## Deploy to Hostinger

**Web app hosting (Business or Cloud plans)**

1. In hPanel go to Websites, add a website, and pick Node.js web app.
2. Import this repository from GitHub.
3. Framework: Express. Entry file: `server.js`. Node 20 or newer.
4. Add the environment variable `ADMIN_PASSWORD`.
5. Set `DATA_DIR` to a folder outside the app directory so submissions are not lost when the app is rebuilt.
6. Deploy.

**VPS with Docker Manager**

Use `docker-compose.yml` from this repo. Replace `YOUR_USERNAME` in it first, and set `ADMIN_PASSWORD` in the environment section of the deploy screen. Submissions are kept in a named volume.

## Use a form

```html
<form action="https://your-formdock-domain.com/f/FORM_ID" method="POST">
  <input type="email" name="email" required>
  <textarea name="message" required></textarea>
  <input type="text" name="_gotcha" style="display:none" tabindex="-1" autocomplete="off">
  <button type="submit">Send</button>
</form>
```

With fetch:

```js
await fetch('https://your-formdock-domain.com/f/FORM_ID', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'ada@example.com', message: 'Hello' }),
});
// → { "ok": true }
```

Field names starting with `_` are never stored.

## Limits

- 20 submissions per minute per IP, per form
- 50 fields per submission, 5,000 characters per field, 100 KB per request
- The newest 5,000 submissions are kept per form
- One admin user. No email notifications yet; use the webhook for alerts

## Tests

```bash
npm test
```

## License

MIT
